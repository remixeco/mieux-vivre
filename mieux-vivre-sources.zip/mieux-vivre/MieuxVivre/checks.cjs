// Run with: node checks.cjs (no packages required).
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const sandbox={window:{},document:{addEventListener(){}},console};
vm.createContext(sandbox);
for(const file of ['program-data.js','guide.js'])vm.runInContext(fs.readFileSync(__dirname+'/Web/'+file,'utf8'),sandbox);
const w=sandbox.window,course=w.MV_COURSE,all=course.flatMap(m=>m.sessions),guide=w.MieuxGuide;
assert.equal(course.length,8);assert.equal(all.length,24);assert.equal(new Set(all.map(s=>s.id)).size,24);
for(const m of course){
 assert.equal(m.sessions.length,3);
 for(const id of m.source)assert(w.MV_SOURCES.some(s=>s.id===id));
 for(const s of m.sessions){for(const key of ['title','example','observe','placeholder','mini','reflect'])assert(s[key]?.length>10);assert.equal(s.learn.length,2);assert.equal(s.practice.length,3);}
}
for(const malformed of [null,1,'string',[],{sessions:{boucle:{step:99,done:'yes',answers:{context:123,outcome:'invalid'}}}}]){
 const n=guide.normalize(malformed);assert.equal(n.size,'short');if(n.sessions.boucle){assert.equal(n.sessions.boucle.step,0);assert.equal(n.sessions.boucle.done,false);assert.equal(n.sessions.boucle.answers.outcome,'');}
}
const raw={size:'micro',started:'2026-11-04',sessions:{boucle:{step:2,done:true,answers:{context:'<img src=x onerror=alert(1)>',reflection:'x'.repeat(900),outcome:'not'}}}};
const normalized=guide.normalize(raw);assert.equal(normalized.sessions.boucle.answers.reflection.length,800);assert.equal(normalized.sessions.boucle.step,2);assert.equal(normalized.size,'micro');
assert(guide.summary({guided:normalized}).includes('1/24'));
// Render the escaped, persisted answers into the same HTML template used by the app.
const elements={};sandbox.document.getElementById=id=>elements[id]||(elements[id]={innerHTML:'',hidden:false,focus(){},scrollIntoView(){}});
guide.render({guided:normalized},()=>true,()=>{},()=>{});
assert(elements['guide-overview'].innerHTML.includes('1 / 24'));
const index=fs.readFileSync(__dirname+'/Web/index.html','utf8');
const ids=[...index.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);assert.equal(new Set(ids).size,ids.length);
for(const f of ['program-data.js','guide.js','app.js','styles.css'])assert(index.includes(f));
const sw=fs.readFileSync(__dirname+'/Web/service-worker.js','utf8');
for(const f of ['program-data.js','guide.js'])assert(sw.includes(f));
assert(index.includes("connect-src 'none'"));
console.log('PASS: content, 24 unique sessions, references, invalid backups, bounded answers, progress, static IDs, offline assets, privacy policy.');
