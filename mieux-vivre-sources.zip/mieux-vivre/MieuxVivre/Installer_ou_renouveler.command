#!/bin/zsh
set -euo pipefail
task_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
task_build="$(mktemp -d "${TMPDIR:-/tmp}/mieux-vivre-build.XXXXXX")"
task_phone="${1:-iPhone de Rémi}"
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
if [[ ! -d "$DEVELOPER_DIR" ]]; then
  print 'Xcode est nécessaire. Installe-le depuis Apple, puis ouvre-le une première fois.'
  exit 1
fi
print 'Branche et déverrouille ton iPhone. La mise à jour conserve les données de Mieux vivre.'
xcodebuild -project "$task_dir/MieuxVivre.xcodeproj" -scheme MieuxVivre \
  -configuration Release -destination 'generic/platform=iOS' \
  -derivedDataPath "$task_build" -allowProvisioningUpdates build
task_app="$task_build/Build/Products/Release-iphoneos/MieuxVivre.app"
codesign --verify --deep --strict "$task_app"
xcrun devicectl device install app --device "$task_phone" "$task_app"
if ! xcrun devicectl device process launch --terminate-existing --device "$task_phone" com.remi.mieuxvivre; then
  print 'Installation effectuée. Si nécessaire, approuve ton compte dans Réglages > Général > VPN et gestion de l’appareil, puis ouvre Mieux vivre.'
fi
print 'Terminé. Ne supprime pas l’application pour renouveler sa signature.'
print 'Tu peux fermer cette fenêtre. Le compte Apple connecté à Xcode gère la signature.'
