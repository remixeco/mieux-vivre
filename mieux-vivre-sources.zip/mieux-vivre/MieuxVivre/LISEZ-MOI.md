# Mieux vivre sur iPhone · version 3.3

Version personnelle d’autoaccompagnement, en français, pour adulte. Elle complète une prise en charge et ne remplace pas un professionnel. Elle n’a pas reçu de validation clinique ou d’évaluation indépendante de sécurité.

## Apparence et Apple Santé

Le bouton **Thème** ouvre les choix **Comme l’iPhone**, **Clair** et **Sombre**. Le bouton **Aide** reste accessible depuis toutes les pages.

Dans **Parcours → Apple Santé → Envoyer mon humeur**, choisis aujourd’hui, les 14 derniers jours ou tout l’historique. Mieux vivre transmet seulement la date et le niveau d’humeur des bilans enregistrés, après autorisation sur l’iPhone. Tes notes et le reste du bilan restent dans le carnet. Cette fonction est disponible à partir d’iOS 18.

[Enregistrer un état d’esprit dans Santé](https://support.apple.com/guide/iphone/log-your-state-of-mind-iph6a6decb13/ios)

## Ce qui a été développé

- Huit chapitres, 24 séances originales : comprendre et observer ; retrouver des activités ; adapter à l’énergie et aux douleurs ; prendre du recul sur les pensées ; résoudre un problème concret ; demander du soutien ; stabiliser les repères ; préparer la suite.
- Chaque séance contient quatre écrans : comprendre, se situer, essayer, retenir. Réponses facultatives, brouillon automatique, navigation libre, version minimum, absence de série ou de pénalité.
- Bilan quotidien, activités personnelles, intentions pour demain, observation subjective avant/après, historique et résumé pour consultation.
- Plan personnel de soutien avec accès aux contacts et aides. L’application ne surveille pas les réponses, n’évalue pas le risque suicidaire et ne contacte personne automatiquement.
- Dossier scientifique avec dix références, nature des preuves et limites. Les 24 séances, leurs durées et leurs adaptations sont des choix pédagogiques et ne constituent pas un protocole validé.
- Application iOS locale incluant son contenu. Le contenu du programme fonctionne sans hébergement ni connexion. Les appels et liens externes nécessitent un réseau. Aucun compte, aucune publicité, aucune analyse d’audience.

## Sur l’iPhone

L’application porte le nom **Mieux vivre**. Ouvrir **Programme**, puis **Commencer**. Toutes les séances sont disponibles dès le début.

Si le compte développeur doit être approuvé : Réglages → Général → VPN et gestion de l’appareil → App du développeur → votre compte → Faire confiance. Une connexion Internet peut être nécessaire pour vérifier le certificat. Le mode développeur était déjà activé sur l’appareil lors de l’installation.

La signature identifie le compte qui signe le code ; elle ne certifie pas la qualité médicale de l’application. Avec un compte personnel gratuit, les profils expirent après sept jours. Après expiration, recompiler et réinstaller avec le même identifiant conserve normalement le conteneur de données : **ne pas désinstaller l’app**.

Source Apple : https://developer.apple.com/help/account/basics/about-your-developer-account
Confiance manuelle : https://help.apple.com/xcode/mac/current/en.lproj/dev96a12fb84.html

## Renouveler depuis le Mac

1. Extraire l’archive et conserver le dossier complet.
2. Brancher et déverrouiller l’iPhone. Utiliser le compte Apple déjà connecté à Xcode.
3. Lancer `Installer_ou_renouveler.command`, ou ouvrir `MieuxVivre.xcodeproj`, sélectionner l’iPhone et exécuter le projet.
4. Le script utilise par défaut le nom « iPhone de Rémi ». Pour un autre nom : `zsh Installer_ou_renouveler.command 'Nom du téléphone'` depuis ce dossier.

Le projet utilise l’équipe personnelle et l’identifiant `com.remi.mieuxvivre` de cette installation. Sur un autre compte Apple, choisir son équipe dans Signing & Capabilities. Il ne contient aucun mot de passe, jeton de connexion ni clé privée de signature. Les outils de compilation doivent être installés par Xcode.

## Données et sauvegardes

Les réponses restent dans le stockage WebKit local de l’app. Elles ne sont pas chiffrées séparément par Mieux vivre ; les protections de l’appareil restent importantes. Une suppression de l’app, un effacement du stockage ou une défaillance peut les faire perdre. L’app n’assure pas de sauvegarde distante.

Dans **Données**, exporter régulièrement une sauvegarde chiffrée `.mvx` : AES-256-GCM, mot de passe d’au moins 12 caractères, PBKDF2-SHA256 avec 250 000 itérations, sel et nonce aléatoires. Le mot de passe n’est pas conservé. La sauvegarde chiffrée protège le fichier exporté, pas les données locales. Aucune garantie de sécurité n’est revendiquée sans audit indépendant.

L’export JSON est lisible en clair et contient potentiellement des informations sensibles. Le partage est toujours initié par la personne. Sur iPhone, la feuille de partage permet notamment d’enregistrer un fichier. Aucune synchronisation automatique entre Safari et cette application.

Les sauvegardes JSON et `.mvx` compatibles des versions 1 et 2 peuvent être restaurées. La restauration remplace les données après confirmation. Les anciennes marques des six étapes sont conservées comme métadonnées, sans être transformées en séances accomplies du nouveau programme.

## Vérifications du 4 novembre 2026

- Syntaxe JavaScript, contenu des 24 séances, références, limites sur les données importées, identifiants HTML et inventaire hors ligne : contrôlés par `node checks.cjs`.
- Interface web : parcours des 24 séances, progression, brouillon après rechargement, mode minimum puis retour, résumé avec notes : vérifiés.
- Création d’un export JSON, export chiffré, restauration de cet export chiffré et import d’une sauvegarde fictive v2 conservant l’activité personnelle et le bilan : vérifiés dans le navigateur de test.
- Affichage au format 393 × 852 : inspecté.
- Compilation Release iPhone, signature, profil autorisant l’appareil, installation et lancement : vérifiés sur l’iPhone 15 Pro connecté.
- Un défaut de chargement des fichiers locaux provoquait un écran blanc. Les chemins d’entrée et d’accès ont été harmonisés ; l’accueil a ensuite été confirmé par capture de l’iPhone réel.
- Non vérifiés de bout en bout sur le téléphone : tous les exercices, la feuille de partage, l’import par Fichiers, le chiffrement dans WebKit iOS, les appels, VoiceOver, le stockage pendant plusieurs semaines et le renouvellement après expiration. Aucun essai clinique ni audit de sécurité effectué.

Le contenu est inclus dans l’app ; le fonctionnement sans réseau n’a pas été testé en coupant la connexion de l’utilisateur.

## Autres usages

Le dossier `Web` contient également la version web progressive. Servir ce dossier en HTTPS pour une installation depuis Safari. Il ne faut pas publier les réponses ou les exports personnels. Cette option est distincte de l’app iPhone installée.

Les liens et synthèses scientifiques se trouvent dans `Web/program-data.js` et dans le dossier scientifique intégré à **Programme** et **Données**. La sélection est ciblée, pas exhaustive. Les textes sont originaux et l’app n’est affiliée à aucune des institutions citées.
